/**
 * @file
 * @brief Simple implementation of the ARGUS protobuf event protocol client side
 *
 * @author Hauke Wulff <hw@mycable.de>
 *
 * @copyright Copyright (c) 2015 mycable GmbH
 *
 * Text encoding: UTF-8
 *
 */

import de.mycable.Argus.ArgusEvent;
import java.io.IOException;
import java.io.OutputStream;
import java.io.DataOutputStream;
import java.net.Socket;
import java.nio.ByteOrder;


public class ArgusSender {

	/**
	 * @brief Java implementation of htonl
	 * 
	 * @param p_value Value to set in network byte order
	 * 
	 * @return p_value in network byte order
	 */
	static int htonl(int p_value)
	{
		  if (ByteOrder.nativeOrder().equals(ByteOrder.LITTLE_ENDIAN))
		  {
		     return p_value;
		  }

		  return Integer.reverseBytes(p_value);
	}
	
	
	/**
	 * @brief Java implementation of htonl
	 * 
	 * @param p_socket Socket to send on
	 * @param p_msg Argus event message to be send
	 * 
	 * @details sendMessage() follows the length-value strategy. The message 
	 * 			length is send at first and then the message itself.
	 */
	static void sendMessage(Socket p_socket, com.google.protobuf.GeneratedMessage p_msg) throws IOException
	{
		OutputStream l_os = p_socket.getOutputStream();
		DataOutputStream l_dos = new DataOutputStream(l_os);
		int l_size = p_msg.getSerializedSize();
		
//        System.out.println("sendMessage(): serializedSize = " + l_size);
        l_dos.writeInt(htonl(l_size));
//		  p_msg.writeDelimitedTo(l_os);
        p_msg.writeTo(l_os);
	}
	
	
	/**
	 * @brief Application entry
	 * 
	 * @param p_args Commandline parameter
	 * 
	 * @throws IOException In case of connection failures
	 * 
	 */
    public static void main(String[] p_args) throws IOException {
    	
        int l_i = 0;
    	
    	ArgusEvent l_evArgusTouch = ArgusEvent.newBuilder()
    			.setType(ArgusEvent.EventType.EVENT_TYPE_EVENT_TOUCH)
    			.build();
    	
    	ArgusEvent l_evArgusStopVideo = ArgusEvent.newBuilder()
    			.setType(ArgusEvent.EventType.EVENT_TYPE_EVENT_STOPVIDEO)
    			.build();

    	ArgusEvent l_evScroll = ArgusEvent.newBuilder()
    			.setType(ArgusEvent.EventType.EVENT_TYPE_EVENT_SCROLL)
    			.setScrolling(ArgusEvent.ScrollType.SCROLL_EVENT_UP)
    			.setScrollAmount(13)
    			.build();

        Socket l_socket = new Socket("localhost", 2345);
        while (l_i < 10)
        {
	        sendMessage(l_socket, l_evArgusTouch);
	        sendMessage(l_socket, l_evArgusStopVideo);
	        sendMessage(l_socket, l_evScroll);
	        
	        l_i++;
        }
        
        l_socket.close();

        System.exit(0);
    }
}

