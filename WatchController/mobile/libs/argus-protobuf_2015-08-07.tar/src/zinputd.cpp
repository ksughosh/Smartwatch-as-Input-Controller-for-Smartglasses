/**
 * @file
 * @brief Simple implementation of the ARGUS protobuf event protocol server side
 *
 * @author Hauke Wulff <hw@mycable.de>
 *
 * @copyright Copyright (c) 2015 mycable GmbH
 *
 * Text encoding: UTF-8
 *
 */


#include <fcntl.h>
#include <string.h>
#include <string>
#include <stdlib.h>
#include <errno.h>
#include <stdio.h>
#include <netinet/in.h>
#include <resolv.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <pthread.h>
#include <iostream>
#include <google/protobuf/io/coded_stream.h>
#include <google/protobuf/io/zero_copy_stream_impl.h>
#include <assert.h>
#include <errno.h>

#include "argus.pb.h"

using namespace std;
using namespace google::protobuf::io;
using namespace argus;

#define TRACE_CALL() \
    fprintf(stderr, "[%s] %s:%d called\n", __FILE__, __PRETTY_FUNCTION__, __LINE__);



/**
 *
 * @brief Decode a protobuf message
 *
 * @param[in] p_csock Pointer to a C socket
 * @param[in] p_length Length of the protobuf message
 *
 * @pre p_csock has to be a valid socket
 *
 */
void decodeMessage(int p_csock, unsigned int p_length)
{
  int l_bytecount = 0;
  ArgusEvent l_payload;
  char l_buffer [p_length];

#if 0
  fprintf(stdout, "p_length = 0x%.4x\n", p_length);
#endif /* 0|1 */

  l_bytecount = recv(p_csock, (void *)l_buffer, p_length, MSG_WAITALL);
  if(l_bytecount == -1)
  {
    fprintf(stderr, "Error receiving data %s\n", strerror(errno));
    return;
  }

  assert(l_bytecount == (int) p_length);

#if 0
    {
        unsigned int l_i = 0u;

        for (unsigned int l_i = 0; l_i < p_length; l_i++)
        {
            fprintf(stdout, "0x%.2x ", buffer[l_i]);
        }
        fprintf(stdout, "\n");
    }
#endif /* 0|1 */

  google::protobuf::io::ArrayInputStream l_ais(l_buffer,p_length);
  CodedInputStream l_coded_input(&l_ais);

  google::protobuf::io::CodedInputStream::Limit l_msgLimit = l_coded_input.PushLimit(p_length);

  l_payload.ParseFromCodedStream(&l_coded_input);

  l_coded_input.PopLimit(l_msgLimit);

#if 0
    fprintf(stdout, "IsInitialized: 0x%x\n", l_payload.IsInitialized());
    fprintf(stdout, "has_type: 0x%x\n", l_payload.has_type());
    fprintf(stdout, "type: 0x%x\n", l_payload.type());
#endif /* 0|1 */

    //Print the message
#if 0
    cout<<"Message is \""<<l_payload.DebugString() << "\"" << endl;
#endif /* 0|1 */

  switch (l_payload.type())
  {
      case ArgusEvent::EVENT_TYPE_EVENT_TOUCH:
          if (l_payload.has_posx() && l_payload.has_posy())
          {
              fprintf(stdout, "Touch event: X = %d; Y = %d\n", l_payload.posx(), l_payload.posy());
          }
          else
          {
              fprintf(stderr, "Either missing posx and/or posy for a touch event\n");
          }
          break;

      case ArgusEvent::EVENT_TYPE_EVENT_SCROLL:
          if (l_payload.has_scrolling() && l_payload.has_scrollamount())
          {
              switch (l_payload.scrolling()) {
                case ArgusEvent::SCROLL_EVENT_UP:
                    fprintf(stdout, "Scroll up with amount = %d\n", l_payload.scrollamount());
                    break;

                case ArgusEvent::SCROLL_EVENT_DOWN:
                    fprintf(stdout, "Scroll down with amount = %d\n", l_payload.scrollamount());
                    break;

                case ArgusEvent::SCROLL_EVENT_UNUSED:
                case ArgusEvent::SCROLL_EVENT_LAST:
                default:
                    fprintf(stderr, "Unknown scrolling event: 0x%x\n", l_payload.scrolling());
                    break;
            }
          }
          else
          {
              fprintf(stderr, "Either missing scrolling and/or scrollamount for a scroll event\n");
          }
          break;

      case ArgusEvent::EVENT_TYPE_EVENT_STOPVIDEO:
          fprintf(stdout, "Stop video event\n");
          break;

      case ArgusEvent::EVENT_TYPE_LAST:
      case ArgusEvent::EVENT_TYPE_UNUSED:
      default:
          fprintf(stderr, "Unexpected message type: 0x%.4x\n", l_payload.type());
          break;
  }

}


/**
 *
 * @brief Reads the message size and calls the message handler
 *
 * @param[in] p_csock Pointer to a C socket
 *
 * @pre p_csock has to be a valid socket
 *
 */
void* SocketHandler(void* p_csock)
{
    int* l_csock = (int*) p_csock;
    char l_buffer[4]          = { 0, };
    unsigned int l_msg_length = 0u;
    unsigned int l_raw        = 0u;
    int l_bytecount           = 0;
    string l_output, l_pl     = "";

    memset(l_buffer, '\0', 4);

    while (1)
    {
        l_raw = 0u;

        l_bytecount = recv(*l_csock, (void*) &l_raw, sizeof(unsigned int), MSG_WAITALL);
        if(l_bytecount == -1)
        {
                fprintf(stderr, "Error receiving data %s\n", strerror(errno));
        }
        else
            if (l_bytecount == 0)
            {
#if 0
                fprintf(stderr, "bytecount == 0\n");
#endif /* 0|1 */
                break;
            }
            else {
#if 0
                fprintf(stdout, "bytecount = 0x%.4x\n", l_bytecount);
#endif /* 0|1 */
                l_msg_length = ntohl(l_raw);
                assert(l_bytecount == sizeof(unsigned int));
#if 0
                fprintf(stdout, "Message payload size = 0x%.4x\n", l_msg_length);
#endif /* 0|1 */
                decodeMessage(*l_csock, l_msg_length);
            }
    }

    free(l_csock);

    return 0;
}



/**
 *
 * @brief Application entry
 *
 * @param[in] argc Argument count
 * @param[in] argv Argument array
 *
 * @return Ever returns
 *
 */
int main(int argc, char* argv[])
{
    int l_host_port                 = 2345;
    int l_hsock                     = 0;
    int* l_pint                     = NULL;
    socklen_t l_addr_size           = 0;
    int* l_csock                    = NULL;
    pthread_t l_tid                 = 0;
    struct sockaddr_in l_in_addr;
    sockaddr_in l_sadr;

    memset(&l_in_addr, '\0', sizeof(struct sockaddr_in));
    memset(&l_sadr, '\0', sizeof(sockaddr_in));

    // Verify that the version of the library that we linked against is
    // compatible with the version of the headers we compiled against.
    GOOGLE_PROTOBUF_VERIFY_VERSION;

    l_hsock = socket(AF_INET, SOCK_STREAM, 0);
    if(l_hsock == -1){
            printf("Error initializing socket %d\n", errno);
            goto FINISH;
    }

    l_pint = (int*)malloc(sizeof(int));
    *l_pint = 1;

    if( (setsockopt(l_hsock, SOL_SOCKET, SO_REUSEADDR, (char*)l_pint, sizeof(int)) == -1 )||
            (setsockopt(l_hsock, SOL_SOCKET, SO_KEEPALIVE, (char*)l_pint, sizeof(int)) == -1 ) ){
            printf("Error setting options %d\n", errno);
            free(l_pint);
            goto FINISH;
    }
    free(l_pint);

    l_in_addr.sin_family = AF_INET ;
    l_in_addr.sin_port = htons(l_host_port);

    memset(&(l_in_addr.sin_zero), 0, 8);
    l_in_addr.sin_addr.s_addr = INADDR_ANY ;

    if( bind( l_hsock, (sockaddr*)&l_in_addr, sizeof(l_in_addr)) == -1 ){
            fprintf(stderr,"Error binding to socket, make sure nothing else is listening on this port %d\n",errno);
            goto FINISH;
    }
    if(listen( l_hsock, 10) == -1 ){
            fprintf(stderr, "Error listening %d\n",errno);
            goto FINISH;
    }

    l_addr_size = sizeof(sockaddr_in);

    while(true){
            printf("waiting for a connection\n");
            l_csock = (int*)malloc(sizeof(int));
            if((*l_csock = accept( l_hsock, (sockaddr*)&l_sadr, &l_addr_size))!= -1){
                    printf("---------------------\nReceived connection from %s\n",inet_ntoa(l_sadr.sin_addr));
                    pthread_create(&l_tid,0,&SocketHandler, (void*)l_csock );
                    pthread_detach(l_tid);
            }
            else{
                    fprintf(stderr, "Error accepting %d\n", errno);
            }
    }

FINISH:
;//oops
}

